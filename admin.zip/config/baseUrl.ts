export const baseURL = "https://politrackafrica.co.ke";
//export const baseURL="http://localhost:8082";
